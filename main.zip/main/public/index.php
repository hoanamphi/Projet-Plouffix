<?php

require '../dev/bootstrap.php';

$app->run();